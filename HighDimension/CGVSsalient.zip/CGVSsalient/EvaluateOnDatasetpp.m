clear
close all
clc
addpath(genpath('E:\PandaSpaceSyn\WorkingSpace\topoFrameworkForJournal\'));
% funDir = cd;
srcDir='E:\PandaSpaceSyn\DataSets\SaliencyDatasets\DUT-OMRON\DUT-OMRON-image\';  %Choose source directory
% srcDir=uigetdir('Choose source directory.');  %Choose source directory
addpath(srcDir);
% cd(srcDir);
allnames=struct2cell(dir([srcDir, '*.jpg'])); % get name strings
[~, pics_num]=size(allnames); % length

resultDir='E:\PandaSpaceSyn\DataSets\SaliencyDatasets\MyResult\DUT\CGVSwithTopo\'; %saving path
allDoneNames=struct2cell(dir([resultDir, 'iter1\','*.png'])); % get name strings
[~, doneImgNum]=size(allDoneNames); % length

% [~, numDoneImg]=size(allDoneNames); % length
% for inum = 1:numDoneImg
%     allDoneList =[allDoneList; allDoneNames{1, inum}];
% end
% cd(funDir);
% pics_num = 10;
tic
parfor_progress(pics_num);
parfor ind_pic = 1:pics_num
    imgPath = allnames{1, ind_pic};
    % original RGB image
    map = double(imread(imgPath))./255;
    resName =  strrep(imgPath,'.jpg','.png'); % fix save name
    
    %%
        if ismember(resName, doneImgNum)
            continue
        end
    %%
    % resize the image for speeding computation
    [ww,hh,dd] = size(map);

    if ww>hh
        map = imresize(map,[300 floor(hh*(300/ww))],'bilinear');
    elseif ww<=hh
        map = imresize(map,[floor(ww*(300/hh)) 300],'bilinear');
    end
    
    if dd==1
        srcImg = cat(3,map,map,map);
    else
        srcImg = map;
    end


    Iter = 2; % time of iteration = Iter -1;

    SOmap = CGVSsalientTopo(srcImg,Iter,resultDir,resName);
%     figure;imshow(SOmap,[]);

    
    parfor_progress;
end
parfor_progress(0);
toc

fprintf(2,'======== THE END ========\n');
%=========================================================================%
