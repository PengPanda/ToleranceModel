clear ;
close all
clc

funDir = cd;
srcDir='E:\SaliencyResult\Images\';  %Choose source directory
% srcDir=uigetdir('Choose source directory.');  %Choose source directory
addpath(srcDir);
cd(srcDir);
allnames=struct2cell(dir('*.jpg')); % get name strings
resultDir='E:\SaliencyResult\CGVS\'; %saving path

[~, pics_num]=size(allnames); % length
cd(funDir);

tic
wbar=waitbar(0,'calculating, please wait!');

for ind_pic = 1:pics_num
    waitbar(ind_pic/pics_num, wbar ,[num2str(100*ind_pic/pics_num) '%']);
    imgPath = allnames{1, ind_pic};
    % original RGB image
    map = double(imread(imgPath))./255;
    resName =  strrep(imgPath,'.jpg','.bmp'); % fix save name
    % resize the image for speeding computation
    [ww,hh,dd] = size(map);
    
    if ww>hh
        map = imresize(map,[300 floor(hh*(300/ww))],'bilinear');
    elseif ww<=hh
        map = imresize(map,[floor(ww*(300/hh)) 300],'bilinear');
    end

    Iter = 3; % time of iteration = Iter -1;

    SOmap = CGVSsalient(map,Iter);
%     figure;imshow(SOmap,[]);
    repath = fullfile(resultDir,resName);     
    imwrite(SOmap,repath,'bmp');
end
toc
close (wbar);
fprintf(2,'======== THE END ========\n');
%=========================================================================%
