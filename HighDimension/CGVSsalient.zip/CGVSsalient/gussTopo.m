% addpath(genpath('E:\PandaSpaceSyn\DataSets\SaliencyDatasets\allDataUsedForEvaluation\ECSSD\FebOTS'))

function image_gauss = gussTopo(srcImage)

% image = imread(imageName);
% [h,w,~] = size(image);
[~, ~, ~,OTS_fullsizeSalMap,~,~,~,~,~,~,~] = GetPriorMap(srcImage);
image = OTS_fullsizeSalMap;
HSIZE = max(size(image))/4;
SIGMA = 20;

H = fspecial('gaussian',HSIZE,SIGMA) ;
image_gauss = NormalizeMap(imfilter(image,H));
% figrue
% imshow(H)
% figure
% imshow(image_gauss)
% title('topoPrior')
% 
% figure
% imshow(image)
% title('topoGaussPrior')