clear
close all

path = '.\';
name = '35058';

scale = [0.1, 0.2, 0.3];

for i=1:3
    imgname = [path name '_' num2str(scale(i)) '_mask' '.png'];
    img =  double(imread(imgname));
    if i ==1
        avgimg =zeros(size(img));
    end
    avgimg = NormalizeMap(avgimg + i*img./3); 
end
 imwrite(avgimg,[path name '_avg_' '.png'],'png' )