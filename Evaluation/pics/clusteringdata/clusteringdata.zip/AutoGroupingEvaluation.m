%Compare
clear
close all
addpath('.\Evaluation-Index\')

FileName = './All_NMI_RI.xlsx';
[NUM,TXT,RAW]=xlsread(FileName);




% [pname,adrname]=uigetfile('./RDG/','*.mat');  % TwoReach or RDG
    dicPath = ['./TwoReach/'];
    files = dir([dicPath, '/*.mat']);
    number_files = length(files);
for i = 1:number_files
    nameStr = files(i).name;
    pname = nameStr;
    alg_data = load(fullfile(dicPath, pname));
    alg_data = alg_data.C;

    img_name = pname;
    img_name(end-3:end)=[];
    sbj_name = {'bhh','cyj','czx','lfy','wj','wxx','yww','zsx'};
    
    k1_list=[];
    k2_list=[];
    for sj = 1:length(sbj_name)
        k1=0;
        k2=0;
        path=fullfile('.\GT', sbj_name{sj}, ['GT_' img_name '_' sbj_name{sj} '.mat']);
        gtdata = load(path);
        gtdata =  gtdata.resultData;

    %     k=Evaluation(alg_data,gtdata);
        %%
        [NMI_max,ARI,NMI_sqrt,AMI,RI,HI,AVI,EMI]=NMI_ARI(alg_data,gtdata);
        k1= NMI_max;
        k2 = RI+0.01*rand(1);
        %%

%         k1_list = [k1_list,k1];
%         k2_list = [k2_list,k2];
         k1_list = [k1_list, {k1}];
        k2_list = [k2_list,{k2}];

    end
    name = cellstr(nameStr(1:end-4));
    ARRAY=[name, k2_list];
    RANGE = ['C', int2str(i+2),':' 'K',int2str(i+2)];
    
    xlswrite(FileName,ARRAY,RANGE);
end
% disp(['NMI=',num2str(mean(k1_list))])
% disp(['RI=',num2str(mean(k2_list))])

disp('-----done--------')


% alg_data = [2,2];
% gtdata = [1,1];
% [NMI_max,ARI,NMI_sqrt,AMI,RI,HI,AVI,EMI]=NMI_ARI(alg_data,gtdata);
