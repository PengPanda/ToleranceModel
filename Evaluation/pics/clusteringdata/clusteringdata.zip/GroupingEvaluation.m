%Compare
clear
close all
addpath('.\Evaluation-Index\')


k1_list=[];
k2_list=[];

[pname,adrname]=uigetfile('./RDG/','*.mat');  % TwoReach or RDG
alg_data = load(fullfile(adrname, pname));
alg_data = alg_data.C;

img_name = pname;
img_name(end-3:end)=[];
sbj_name = {'bhh','cyj','czx','lfy','wj','wxx','yww','zsx'};
for sj = 1:length(sbj_name)
    k1=0;
    k2=0;
    path=fullfile('.\GT', sbj_name{sj}, ['GT_' img_name '_' sbj_name{sj} '.mat']);
    gtdata = load(path);
    gtdata =  gtdata.resultData;
    
%     k=Evaluation(alg_data,gtdata);
    %%
    [NMI_max,ARI,NMI_sqrt,AMI,RI,HI,AVI,EMI]=NMI_ARI(alg_data,gtdata);
    k1= NMI_max;
    k2 = RI;
    %%
    
    k1_list = [k1_list,k1];
    k2_list = [k2_list,k2];

end
disp(['NMI=',num2str(mean(k1_list))])
disp(['RI=',num2str(mean(k2_list))])

% alg_data = [2,2];
% gtdata = [1,1];
% [NMI_max,ARI,NMI_sqrt,AMI,RI,HI,AVI,EMI]=NMI_ARI(alg_data,gtdata);
