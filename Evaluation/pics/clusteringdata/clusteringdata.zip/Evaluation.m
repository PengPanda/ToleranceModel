function p = Evaluation(data1,data2)
%% evaluation
% clear
% GT = [1,1,2,2];
% % 
% data = [1,1,1,1];

% 
data=data1;
GT=data2;

len = length(GT(:));
len1 = length(data(:));

assert(len==len1, ['The length of Compared data is not equal!']);

uniGT = unique(GT);
uniData = unique(data);
k = 0;

for u = uniGT
   indx = find(GT==u);
   k = k + 1 - length(unique(data(indx)));     
end

for n = uniData
   indx = find(data==n);
   k = k + 1 - length(unique(GT(indx)));     
end

p = 1+k/len;
